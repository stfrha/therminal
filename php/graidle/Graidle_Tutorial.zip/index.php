<h3><a href="../DL/Graidle_Tutorial.zip">Download Tutorials</a></h3>
<ul>
	<li><a href="#" onClick="window.open('esempi/barre0.php','','height=600,width=800');">Barre1</a></li>
	<li><a href="#" onClick="window.open('esempi/barre1.php','','height=600,width=800');">Barre2</a></li>
	<li><a href="#" onClick="window.open('esempi/barre2.php','','height=600,width=800');">Barre3</a></li>
	<li><a href="#" onClick="window.open('esempi/barre3.php','','height=600,width=800');">Barre4</a></li>
	<br />
	<li><a href="#" onClick="window.open('esempi/hbar0.php','','height=600,width=800');">Orizzontale1</a></li>
	<li><a href="#" onClick="window.open('esempi/hbar1.php','','height=600,width=800');">Orizzontale2</a></li>
	<br />
	<li><a href="#" onClick="window.open('esempi/linea0.php','','height=600,width=800');">Linee1</a></li>
	<li><a href="#" onClick="window.open('esempi/linea1.php','','height=600,width=800');">Linee2</a></li>
	<li><a href="#" onClick="window.open('esempi/linea2.php','','height=600,width=800');">Linee3</a></li>
	<br />
	<li><a href="#" onClick="window.open('esempi/conf0.php','','height=600,width=800');">Misto1</a></li>
	<li><a href="#" onClick="window.open('esempi/conf1.php','','height=600,width=800');">Misto2</a></li>
	<br />
	<li><a href="#" onClick="window.open('esempi/pie0.php','','height=600,width=800');">Torta1</a></li>
	<li><a href="#" onClick="window.open('esempi/pie1.php','','height=600,width=800');">Torta2</a></li>
	<li><a href="#" onClick="window.open('esempi/pie2.php','','height=600,width=800');">Torta3</a></li>
	<br />
	<li><a href="#" onClick="window.open('esempi/pieno0.php','','height=600,width=800');">Pieno1</a></li>
	<li><a href="#" onClick="window.open('esempi/pieno1.php','','height=600,width=800');">Pieno2</a></li>
	<br />
	<li><a href="#" onClick="window.open('esempi/spider0.php','','height=600,width=800');">Ragno1</a></li>
</ul>